#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ddq.h"
#include "oplib.h"
#include "error.h"

// --------------------- Matrix 数据结构 ---------------------
typedef struct {
    float *data;
    int rows;
    int cols;
} Matrix;

// 全局变量保存各层输出
static obj g_conv_out = NULL;
static obj g_relu_out = NULL;
static obj g_pool_out = NULL;
static obj g_fc_out   = NULL;

// 动态输入尺寸
int input_height;
int input_width;
int kernel_rows;
int kernel_cols;
// 归一化因子
#define NORMALIZATION_FACTOR 255.0f

#define POOL_SIZE         2

// 根据输入尺寸计算各层输出尺寸
#define CONV_OUT_HEIGHT   (input_height - kernel_rows + 1)
#define CONV_OUT_WIDTH    (input_width - kernel_cols + 1)
#define POOL_OUT_HEIGHT   (CONV_OUT_HEIGHT / POOL_SIZE)
#define POOL_OUT_WIDTH    (CONV_OUT_WIDTH / POOL_SIZE)
#define FC_OUTPUT         POOL_OUT_HEIGHT * POOL_OUT_WIDTH  // 全连接层输出尺寸
#define MAX_CONV_LAYERS 1  // 限定卷积层数

// --------------------- Matrix 操作 ---------------------
Matrix* new_matrix(int rows, int cols) {
    printf("[new_matrix] allocating %dx%d matrix\n", rows, cols);
    Matrix *m = (Matrix*) malloc(sizeof(Matrix));
    if (!m) {
        fprintf(stderr, "[new_matrix] Error allocating Matrix struct\n");
        exit(EXIT_FAILURE);
    }
    m->rows = rows;
    m->cols = cols;
    m->data = (float*) calloc(rows * cols, sizeof(float));
    if (!m->data) {
        fprintf(stderr, "[new_matrix] Error allocating Matrix data\n");
        free(m);
        exit(EXIT_FAILURE);
    }
    printf("[new_matrix] done\n");
    return m;
}

/**
 * 从文件读取输入数据，并进行归一化处理
 * @param filename 输入文件路径
 * @return 读取并归一化后的输入矩阵
 */
Matrix* read_and_normalize_input(const char* filename) {
    // 读取输入文件的尺寸
    FILE* file = fopen(filename, "r");
    if (!file) {
        fprintf(stderr, "无法打开输入文件：%s\n", filename);
        exit(EXIT_FAILURE);
    }

    // 读取输入矩阵的尺寸
    if (fscanf(file, "%d %d", &input_height, &input_width) != 2) {
        fprintf(stderr, "输入文件格式错误，需第一行为尺寸\n");
        exit(EXIT_FAILURE);
    }

    // 创建输入矩阵
    Matrix* input = new_matrix(input_height, input_width);
    int total_elements = input->rows * input->cols;

    // 读取输入数据
    for (int i = 0; i < total_elements; i++) {
        if (fscanf(file, "%f", &input->data[i]) != 1) {
            fprintf(stderr, "读取输入数据时出错\n");
            exit(EXIT_FAILURE);
        }
    }

    // 关闭文件
    fclose(file);

    // 对输入数据进行归一化处理
    float max_val = 0.0f;
    for (int i = 0; i < total_elements; i++) {
        if (input->data[i] > max_val) {
            max_val = input->data[i];
        }
    }

    // 防止除以零
    if (max_val == 0.0f) {
        return input;
    }

    for (int i = 0; i < total_elements; i++) {
        input->data[i] = input->data[i] / max_val;
    }

    return input;
}

/**
 * 从文件读取卷积核
 * 文件格式要求：
 *   第一行：<kernel_rows> <kernel_cols>
 *   后续内容：kernel_rows * kernel_cols个浮点数
 * @param filename 卷积核文件路径
 * @return 读取的卷积核矩阵
 */
Matrix* read_conv_kernel(const char* filename) {
    FILE* file = fopen(filename, "r");
    if (!file) {
        fprintf(stderr, "无法打开卷积核文件：%s\n", filename);
        exit(EXIT_FAILURE);
    }
    if (fscanf(file, "%d %d", &kernel_rows, &kernel_cols) != 2) {
        fprintf(stderr, "卷积核文件格式错误，第一行应为两个整数\n");
        exit(EXIT_FAILURE);
    }
    Matrix* kernel = new_matrix(kernel_rows, kernel_cols);
    int total = kernel_rows * kernel_cols;
    for (int i = 0; i < total; i++){
        if (fscanf(file, "%f", &kernel->data[i]) != 1) {
            fprintf(stderr, "读取卷积核文件时出错\n");
            exit(EXIT_FAILURE);
        }
    }
    fclose(file);
    return kernel;
}

void free_matrix(Matrix *m) {
    if(m) {
        printf("[free_matrix] freeing matrix %dx%d\n", m->rows, m->cols);
        free(m->data);
        free(m);
        printf("[free_matrix] done\n");
    }
}

// --------------------- CNN 算子实现 ---------------------

task_ret cnn_conv(void **inputs, void **outputs, void **attribute) {
    static int conv_layer_count = 0;
    if (conv_layer_count >= MAX_CONV_LAYERS) {
        printf("[cnn_conv] 已达到最大卷积层数 (%d)，任务结束\n", MAX_CONV_LAYERS);
        return task_ret_done;
    }
    conv_layer_count++;
    printf("[cnn_conv] start, 当前卷积层数: %d\n", conv_layer_count);

    // inputs[0]为输入矩阵，inputs[1]为卷积核
    Matrix *in = (Matrix*) inputs[0];
    Matrix *kernel = (Matrix*) inputs[1];
    Matrix *out = (Matrix*) outputs[0];

    int conv_out_height = in->rows - kernel->rows + 1;
    int conv_out_width  = in->cols - kernel->cols + 1;
    out->rows = conv_out_height;
    out->cols = conv_out_width;
    printf("[cnn_conv] input size: %dx%d, kernel size: %dx%d, output size: %dx%d\n",
           in->rows, in->cols, kernel->rows, kernel->cols, conv_out_height, conv_out_width);
    for (int i = 0; i < conv_out_height; i++) {
        for (int j = 0; j < conv_out_width; j++) {
            float sum = 0.0f;
            for (int ki = 0; ki < kernel->rows; ki++) {
                for (int kj = 0; kj < kernel->cols; kj++) {
                    sum += in->data[(i + ki) * in->cols + (j + kj)]
                           * kernel->data[ki * kernel->cols + kj];
                }
            }
            out->data[i * out->cols + j] = sum;
        }
    }

    printf("[cnn_conv] done\n");
    return task_ret_ok;
}


task_ret cnn_relu(void **inputs, void **outputs, void **attribute) {
    printf("[cnn_relu] start\n");
    Matrix *in = (Matrix*) inputs[0];
    Matrix *out = (Matrix*) outputs[0];
    int total = in->rows * in->cols;
    for (int i = 0; i < total; i++){
        float val = in->data[i];
        out->data[i] = (val > 0.0f ? val : 0.0f);
    }
    printf("[cnn_relu] done\n");
    return task_ret_ok;
}

task_ret cnn_pool(void **inputs, void **outputs, void **attribute) {
    printf("[cnn_pool] start\n");
    Matrix *in = (Matrix*) inputs[0];
    Matrix *out = (Matrix*) outputs[0];

    // 根据输入矩阵的尺寸计算池化输出尺寸
    int pool_out_height = in->rows / POOL_SIZE;
    int pool_out_width = in->cols / POOL_SIZE;
    out->rows = pool_out_height;
    out->cols = pool_out_width;
    printf("[cnn_pool] input size: %dx%d, output size: %dx%d\n", in->rows, in->cols, pool_out_height, pool_out_width);
    for (int i = 0; i < pool_out_height; i++) {
        for (int j = 0; j < pool_out_width; j++) {
            float max_val = -1e10;
            for (int pi = 0; pi < POOL_SIZE; pi++) {
                for (int pj = 0; pj < POOL_SIZE; pj++) {
                    int row = i * POOL_SIZE + pi;
                    int col = j * POOL_SIZE + pj;
                    float val = in->data[row * in->cols + col];
                    if (val > max_val) {
                        max_val = val;
                    }
                }
            }
            out->data[i * out->cols + j] = max_val;
        }
    }
    printf("[cnn_pool] done\n");
    return task_ret_ok;
}


task_ret cnn_fc(void **inputs, void **outputs, void **attribute) {
    printf("[cnn_fc] start\n");
    Matrix *in = (Matrix*) inputs[0];
    Matrix *fc_out = (Matrix*) outputs[0];
    int in_size = in->rows * in->cols;

    fc_out->rows = 1;
    fc_out->cols = in_size;

    for (int i = 0; i < in_size; i++) {
        fc_out->data[i] = in->data[i];
    }
    
    printf("[cnn_fc] done\n");
    return task_ret_done;
}


// --------------------- 新增打印矩阵的操作函数 ---------------------
task_ret f_print_matrix(void **inputs, void **outputs, void **attribute) {
    Matrix *m = (Matrix*) inputs[0];
    if (!m) {
        printf("[f_print_matrix] 输入矩阵为空\n");
        return task_ret_ok;
    }
    printf("---- 打印矩阵 (%dx%d) ----\n", m->rows, m->cols);
    for (int i = 0; i < m->rows; i++){
        for (int j = 0; j < m->cols; j++){
            printf("%6.2f ", m->data[i * m->cols + j]);
        }
        printf("\n");
    }
    printf("---- 打印结束 ----\n");
    return task_ret_ok;
}

// --------------------- 构建 CNN DDQ 算子图 ---------------------


/**
 * 创建并初始化CNN环，接受动态输入
 * @param input 输入矩阵
 * @return ddq_ring对象
 */
ddq_ring cnn_ring(Matrix* input, Matrix* conv_kernel) {
    // 新建一个环对象，包含1个全局输入，0个全局输出
    ddq_ring ring = ddq_new(NULL, 2, 0);

    // 创建各层输出矩阵，尺寸根据输入动态计算（添加了类型转换以消除警告）
    g_conv_out = (obj)new_matrix(CONV_OUT_HEIGHT, CONV_OUT_WIDTH);
    g_relu_out = (obj)new_matrix(CONV_OUT_HEIGHT, CONV_OUT_WIDTH);
    g_pool_out = (obj)new_matrix(POOL_OUT_HEIGHT, POOL_OUT_WIDTH);
    g_fc_out   = (obj)new_matrix(1, FC_OUTPUT);

    // 将输入矩阵封装为对象
    ring->inputs[0] = obj_import(ring, input, (destruct_f*)free_matrix, obj_prop_ready);
    ring->inputs[1] = obj_import(ring, conv_kernel, (destruct_f*)free_matrix, obj_prop_ready);

    // 使用obj_import对算子函数进行包装
    obj cnn_conv_obj = obj_import(ring, cnn_conv, NULL, obj_prop_ready);
    obj cnn_relu_obj = obj_import(ring, cnn_relu, NULL, obj_prop_ready);
    obj cnn_pool_obj = obj_import(ring, cnn_pool, NULL, obj_prop_ready);
    obj cnn_fc_obj   = obj_import(ring, cnn_fc, NULL, obj_prop_ready);

    // 将各层输出矩阵封装为对象，传递给各个算子（同样添加类型转换）
    g_conv_out = obj_import(ring, g_conv_out, (destruct_f*)free_matrix, obj_prop_consumable);
    g_relu_out = obj_import(ring, g_relu_out, (destruct_f*)free_matrix, obj_prop_consumable);
    g_pool_out = obj_import(ring, g_pool_out, (destruct_f*)free_matrix, obj_prop_consumable);
    g_fc_out   = obj_import(ring, g_fc_out, (destruct_f*)free_matrix, obj_prop_consumable);

    // 创建任务节点，连接各个算子
    ddq_op t_conv = ddq_spawn(ring, processor_pthread, 2, 1);
    ddq_add_f(t_conv, cnn_conv_obj);
    ddq_add_inputs(t_conv, 0, ring->inputs[0]);
    ddq_add_inputs(t_conv, 1, ring->inputs[1]);
    ddq_add_outputs(t_conv, 0, g_conv_out);

    ddq_op t_relu = ddq_spawn(ring, processor_pthread, 1, 1);
    ddq_add_f(t_relu, cnn_relu_obj);
    ddq_add_inputs(t_relu, 0, g_conv_out);
    ddq_add_outputs(t_relu, 0, g_relu_out);

    ddq_op t_pool = ddq_spawn(ring, processor_pthread, 1, 1);
    ddq_add_f(t_pool, cnn_pool_obj);
    ddq_add_inputs(t_pool, 0, g_relu_out);
    ddq_add_outputs(t_pool, 0, g_pool_out);

    ddq_op t_fc = ddq_spawn(ring, processor_pthread, 1, 1);
    ddq_add_f(t_fc, cnn_fc_obj);
    ddq_add_inputs(t_fc, 0, g_pool_out);
    ddq_add_outputs(t_fc, 0, g_fc_out);

    ddq_op t_print = ddq_spawn(ring, processor_pthread, 1, 0);
    obj print_matrix_obj = obj_import(ring, f_print_matrix, NULL, obj_prop_ready);
    ddq_add_f(t_print, print_matrix_obj);
    ddq_add_inputs(t_print, 0, g_fc_out);

    return ring;
}

int main(int argc, char** argv) {
    // 必须传入两个参数：输入文件路径和卷积核文件路径
    if (argc != 3) {
        printf("使用方法：./cnn_app <input_file_path> <conv_kernel_file_path>\n");
        return EXIT_FAILURE;
    }

    printf("Starting CNN DDQ execution...\n");

    Matrix* input = read_and_normalize_input(argv[1]);
    Matrix* conv_kernel = read_conv_kernel(argv[2]);

    // 创建并初始化CNN环
    ddq_ring ring = cnn_ring(input, conv_kernel);
    printf("Calling ddq_update\n");
    ddq_update(ring);
    printf("Entering ddq_loop\n");
    ddq_loop(ring, 0);
    printf("CNN computation completed.\n");

    ddq_delete(ring);
    printf("Resources cleaned up, exiting.\n");

    return 0;
}

